<?php
require_once 'connexion.php';
echo "OK";
?>